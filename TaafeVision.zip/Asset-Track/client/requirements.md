## Packages
framer-motion | Page transitions and scroll animations
lucide-react | Icons for the UI
date-fns | Formatting dates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
